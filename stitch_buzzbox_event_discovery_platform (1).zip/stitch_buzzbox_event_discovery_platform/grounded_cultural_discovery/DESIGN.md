---
name: Grounded Cultural Discovery
colors:
  surface: '#f7faf4'
  surface-dim: '#d8dbd5'
  surface-bright: '#f7faf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f5ee'
  surface-container: '#ecefe9'
  surface-container-high: '#e6e9e3'
  surface-container-highest: '#e0e3dd'
  on-surface: '#181d19'
  on-surface-variant: '#404942'
  inverse-surface: '#2d312d'
  inverse-on-surface: '#eff2eb'
  outline: '#707a71'
  outline-variant: '#bfc9bf'
  surface-tint: '#1f6b45'
  primary: '#1c6942'
  on-primary: '#ffffff'
  primary-container: '#398259'
  on-primary-container: '#f6fff5'
  inverse-primary: '#8cd6a7'
  secondary: '#496552'
  on-secondary: '#ffffff'
  secondary-container: '#cbead2'
  on-secondary-container: '#4f6b58'
  tertiary: '#8f454f'
  on-tertiary: '#ffffff'
  tertiary-container: '#ad5d66'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a7f3c2'
  primary-fixed-dim: '#8cd6a7'
  on-primary-fixed: '#002110'
  on-primary-fixed-variant: '#005230'
  secondary-fixed: '#cbead2'
  secondary-fixed-dim: '#b0ceb7'
  on-secondary-fixed: '#062012'
  on-secondary-fixed-variant: '#324d3b'
  tertiary-fixed: '#ffdadc'
  tertiary-fixed-dim: '#ffb2b9'
  on-tertiary-fixed: '#3d0511'
  on-tertiary-fixed-variant: '#75303a'
  background: '#f7faf4'
  on-background: '#181d19'
  surface-variant: '#e0e3dd'
typography:
  display-hero:
    fontFamily: Epilogue
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined, culturally grounded editorial aesthetic tailored for discerning event discovery, art curation, and premium ticketing experiences. The visual atmosphere moves away from frantic festival styling, fluorescent nightclub accents, and synthetic tech gradients, leaning instead into tactile print tradition, curated museum monographs, and deliberate architectural restraint.

The identity pairs high-fashion editorial gravitas with effortless utilitarian speed. Surfaces evoke warm heavy-weight paper stocks, natural mineral pigments, and patinated metals. Clean editorial display headings anchor the page with intellectual presence, while modern geometric body typography delivers clinical precision for schedules, ticketing tiers, and navigational primitives.

Interactions are calm, physical, and weighted: surfaces lift with soft mineral shadows, dock bars float cleanly above content like precision optical instruments, and ticketing passes adopt understated physical notch motifs rather than novelty skeuomorphism.

## Colors

The palette is strictly mineral, earthy, and natural, explicitly rejecting synthetic fluorescents, saturated neons, and cybernetic glows.

### Color Tokens & Semantic Roles
- **Primary (`#3C855C` - Forest Green):** The core grounding tone. Used for dominant action buttons, high-impact titles, key interactive states, and solid structural fills.
- **Secondary (`#627E6A` - Sage Olive):** Secondary interactive elements, active category chips, subtle iconography, and descriptive highlights that require organic warmth without high contrast.
- **Tertiary (`#E98E98` - Muted Rose):** Reserved for deliberate points of focus: limited ticket indicators, sold-out alerts, curated recommendations, and date stamps.
- **Neutral Canvas (`#747873` - Mineral Gray):** The primary editorial background. Replaces stark cold whites with the tactile feel of uncoated museum catalog stock.
- **Neutral Surface / Containers (`#FFFFFF` - Pure White):** Crisp card containers, elevated sheets, and ticket passes layered against the canvas to establish clarity and tactile layering.
- **Subtle Surface Tint (`#E8E5DC` - Warm Stone):** Ghost borders, divider rules, passive chips, subtle card outlines, and segmented control tracks.
- **Immersive Dark Tone (`#202320` - Deep Charcoal):** Deep contrast layer used for nighttime previews, floating dock backgrounds, dark mode stages, and high-impact editorial feature cards.

## Typography

Typography establishes an intentional cadence between editorial distinction and functional clarity.

- **Headlines (Epilogue):** An architectural, geometric display face that introduces personality and editorial authority. Used in deliberate sentence case or title case. Large headlines maintain tight negative tracking (`-0.02em` to `-0.03em`) to lock character pairs into solid editorial blocks.
- **Body & UI Elements (Plus Jakarta Sans):** A friendly, contemporary geometric sans-serif tuned for screen legibility at small sizes. Used for ticket specifications, metadata, forms, and dense event schedules.
- **Label & Metadata Hierarchy:** Editorial timestamps, artist tags, and seating zones leverage `label-caps` set in uppercase with expanded tracking (`0.08em`) to mimic physical print catalog callouts.

## Layout & Spacing

The layout balances architectural order with rhythmic asymmetry:

- **Desktop (12 Columns):** Fluid grid maxing out at `1360px` centered canvas, with `2.5rem` outer margin and `1.25rem` gutters. Asymmetric pairings create magazine-inspired layouts.
- **Tablet (8 Columns):** `1.5rem` outer margins and `1rem` gutters, supporting dual-column event streams.
- **Mobile (4 Columns & Asymmetric 2-Column Feeds):** Edge margin scales to `1rem` with `0.75rem` gutters. Event listings flow in staggered or equal 2-column cards designed for one-handed thumb navigation.
- **Vertical Spacing Cadence:** Base rhythm follows an 8px scale. Generous vertical gaps (`space-xl` and above) between curated sections prevent cognitive crowding, reinforcing the tranquil museum atmosphere.

## Elevation & Depth

Visual depth is achieved through structural tonal layering, crisp borders, and subtle organic ambient shadows rather than intense dropshadows or neon blurs.

- **Level 0 (Canvas Base):** Neutral Canvas serving as the ground plane.
- **Level 1 (Crisp Resting Cards & Sheets):** Pure White containers framed with a `1px` solid border.
- **Level 2 (Hover / Active State):** Subtle card elevation with upward translation and a tinted ambient shadow.
- **Level 3 (Floating Dock & Overlays):** Deep Charcoal dock or frosted surface utilizing `backdrop-filter: blur(16px)` with an ambient shadow.

## Shapes

With a roundedness factor of `2`, the system exhibits tailored, sculptural curvature that feels human and physical:

- **Standard Elements (Buttons, Inputs, Small Badges):** `0.5rem` (8px) corner radius, providing crisp tactile definition.
- **Containers & Event Cards (`rounded-lg`):** `1rem` (16px) corner radius, softening the transition between photographic imagery and framing.
- **Feature Modules & Modals (`rounded-xl`):** `1.5rem` (24px) corner radius.
- **Dock & Status Pills (`rounded-full`):** Complete pill curvature (`9999px`) used exclusively for category chips, state tags, and the floating navigation dock.
- **Physical Ticket Geometry:** Digital passes use inverted inward corner cutouts (`8px` circular notches) along perforations, creating an authentic cultural ticket silhouette.

## Components

### Buttons
- **Primary:** Primary Forest Green background, Pure White text, `0.5rem` radius, semi-bold typography (`label-md`). Hover transitions with a smooth micro-scale translation.
- **Secondary:** Surface background, framed with a `1px` subtle border, Primary text.
- **Accent:** Muted Rose background with white text, strictly reserved for immediate checkout actions or high-priority booking milestones.

### Floating Dock Bottom Navigation
- **Structure:** Floating island positioned `1rem` above the bottom safe area, auto-width or max `380px` on mobile.
- **Surface:** Deep Charcoal with `0.92` opacity, backdrop blur `16px`.
- **Active Indicator:** Smooth spring pill background highlighting the active destination icon and title.

### Event Cards
- **Editorial Cards:** Pure White card base, `1rem` radius, subtle hairline outline. Top image aspect ratio `4:3` or `16:10` with natural photography.
- **Asymmetric Grid Display:** Alternating single wide highlight cards with paired 2-column mobile cards to maintain visual rhythm during browsing.

### Ticket Notch Geometry
- **Ticket Passes:** Divided into a primary stub and secondary stub separated by a perforated dotted rule punctuated on both edges by smooth circular inward cutout notches matching the underlying background canvas.

### Chips & Segmented Controls
- **Category Chips:** Pill-shaped, bordered on canvas. Selected state adopts Primary fill with white text.
- **Segmented Controls:** Housed inside a recessed track with `0.5rem` radius; sliding active indicator has a pure white surface with a delicate ambient shadow.

### Input Fields & Search Bars
- **Styling:** Recessed or flat fills with clean `1px` subtle borders. Focused state transitions border to Primary without neon halo rings. Placeholder text is rendered in Muted Olive at `60%` opacity.